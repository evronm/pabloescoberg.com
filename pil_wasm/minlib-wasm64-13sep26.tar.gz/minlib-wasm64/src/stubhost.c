// Stub host for the minlib embedding ABI.
//
// Milestone 1 of the wasm64 port: prove that the picolisp()/evaluate()
// contract survives on a platform that cannot longjmp into a returned frame.
// picolisp() setjmp's QuitRst and then returns; evaluate() longjmp's back into
// that dead frame. This program is the smallest thing that exercises it, and is
// built both natively (reference) and for wasm64.

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "test_exprs.h"

// minlib
int picolisp(char *stack, int size, int ac, char **av);
char *evaluate(char *expr);
void stoplisp(void);

static char Stack[1024 * 1024];

static void try(const char *expr) {
   char *res;

   printf("eval  %-34s", expr);
   fflush(stdout);
   res = evaluate((char*)expr);
   printf(" -> %s\n", res ? res : "(null)");
   fflush(stdout);
   free(res);
}

int main(int ac, char *av[]) {
   // loadAll() walks $AV until it hits a NULL slot or a bare "-", so the
   // vector must be terminated. sdl2gui.c gets that for free because init()
   // nulls the trailing "+" (debug mode) slot; a release host wants "-".
   static char *init[] = {"stubhost", "lib.l", "-"};

   printf("calling picolisp()\n");
   fflush(stdout);
   if (!picolisp(Stack, sizeof(Stack), (int)(sizeof(init)/sizeof(char*)), init)) {
      fprintf(stderr, "picolisp() failed\n");
      return 1;
   }
   printf("picolisp() returned; host frame is live again\n");
   fflush(stdout);

   // Expressions on the command line replace the built-in suite, which makes
   // this usable for probing: works natively and under `node stubhost.js ...`.
   if (ac > 1)
      while (--ac)
         try(*++av);
   else
      for (int i = 0; TestExprs[i]; ++i)
         try(TestExprs[i]);

   printf("calling stoplisp()\n");
   fflush(stdout);
   stoplisp();
   printf("done\n");
   return 0;
}
