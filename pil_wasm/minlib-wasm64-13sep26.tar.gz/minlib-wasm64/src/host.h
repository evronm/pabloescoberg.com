// Host side of minlib's C ABI, factored out of main.l.
//
// main.l (see main.l.patch) now hands control to the host in exactly one place,
// hostYield(), instead of longjmp'ing between two jmp_bufs across a relocated
// machine stack. Each host_*.c provides that hand-over for one platform:
//
//   host_setjmp.c    setjmp/longjmp, exactly as upstream main.l did. Native.
//   host_fiber.c     Emscripten fibers. wasm64, keeps the published ABI.
//   host_inverted.c  No stack switching; the host supplies work by callback.
//                    wasm64, changes the published ABI.

#ifndef PIL_HOST_H
#define PIL_HOST_H

#include <stdint.h>
#include <setjmp.h>

// Commands returned by hostYield() to the interpreter.
#define PIL_QUIT     0
#define PIL_EVALUATE 2
#define PIL_REFLECT  3

// Interpreter side, from the patched main.l.
int  lispMain(char *stack, int size, int ac, char **av);
int  hostReflect(char *adr, char *str);

// $Ret / $Ret2 are Lisp globals; reach them under their real (non-C) names.
extern uint64_t Pil_Ret  __asm__("$Ret");
extern uint64_t Pil_Ret2 __asm__("$Ret2");

// glob.l's exit flag (an i1). An uncaught Lisp error ends in bye(), which
// unwinds every catch frame and coroutine and then calls exit() -- and exit()
// does not actually terminate a wasm module, so the interpreter is left half
// dismantled and the next call into it crashes. A host cannot prevent that,
// but it can notice: $InBye is NO until bye() runs and never goes back.
extern unsigned char Pil_InBye __asm__("$InBye");

// Defined in lib.so.c.
extern jmp_buf SoRst;
extern jmp_buf QuitRst;

// The fiber the interpreter itself runs on, or NULL if this host does not use
// one. src/crt_fiber.c borrows it for PicoLisp's "main" coroutine, so that
// exactly one fiber handle ever describes that stack.
#ifdef __EMSCRIPTEN__
struct emscripten_fiber_s;
struct emscripten_fiber_s *pilHostSideFiber(void);
#endif

#endif
