#!/bin/bash
# Verify the browser build in a real browser, against the native reference.
#
# A headless screenshot cannot tell you whether the module ever loaded, so
# selftest.html reports each step back with fetch() and testserver.py collects
# it. Phase 1 drives the wasm exports; phase 2 drives index.html itself, in an
# iframe, through its own event listeners.
#
#   ./run-browser-test.sh [port]
#
# Needs bin/web/ built (make -f Makefile.wasm browser) and bin/stubgui-upstream
# for the reference digests (make -f Makefile.wasm reference-gui).

set -u
PORT=${1:-8791}
OUT=/tmp/minlib-browser
PROFILE=/tmp/minlib-ffprof
HERE=$(cd "$(dirname "$0")" && pwd)
BIN=$HERE/../../bin

BROWSER=${BROWSER:-firefox}
command -v "$BROWSER" >/dev/null || { echo "no $BROWSER on PATH"; exit 2; }
[ -f "$BIN/web/picolisp.wasm" ] || { echo "bin/web not built"; exit 2; }
[ -x "$BIN/stubgui-upstream" ] || { echo "bin/stubgui-upstream not built"; exit 2; }

# Native reference digests, in order.
mapfile -t REF < <("$BIN/stubgui-upstream" 2>/dev/null |
   sed -n 's/^framebuffer \([0-9a-f]*\).*/\1/p')
[ ${#REF[@]} -eq 6 ] || { echo "expected 6 reference digests, got ${#REF[@]}"; exit 2; }

cleanup() {
   [ -n "${FF:-}" ] && kill "$FF" 2>/dev/null
   [ -n "${SRV:-}" ] && kill "$SRV" 2>/dev/null
   wait 2>/dev/null
}
trap cleanup EXIT

rm -rf "$OUT" "$PROFILE"
mkdir -p "$OUT" "$PROFILE"

python3 "$HERE/testserver.py" "$PORT" "$OUT" >/tmp/minlib-testserver.log 2>&1 &
SRV=$!
sleep 1
kill -0 $SRV 2>/dev/null || { echo "server failed to start (port $PORT in use?)";
   cat /tmp/minlib-testserver.log; exit 2; }

MOZ_HEADLESS=1 "$BROWSER" --headless --no-remote --new-instance \
   --profile "$PROFILE" "http://127.0.0.1:$PORT/selftest.html" \
   >/tmp/minlib-browser.log 2>&1 &
FF=$!

# Wait for the page to finish rather than sleeping a fixed amount.
for i in $(seq 120); do
   grep -q ' DONE$' "$OUT/selftest.log" 2>/dev/null && break
   sleep 1
done

# The page numbers its reports because fetch() does not preserve ordering;
# sort by that number and strip it before matching.
LOG=$OUT/ordered.log
sort -n "$OUT/selftest.log" | sed 's/^[0-9]* //' > "$LOG"
fail=0
check() { # label actual expected
   if [ "$2" = "$3" ]; then
      printf '  %-22s %s  ok\n' "$1" "$2"
   else
      printf '  %-22s %s  EXPECTED %s\n' "$1" "${2:-<missing>}" "$3"
      fail=1
   fi
}

if ! grep -q '^DONE$' "$LOG" 2>/dev/null; then
   echo "browser never reported DONE; log so far:"
   cat "$LOG" 2>/dev/null
   exit 1
fi

echo "phase 1 -- wasm exports, six framebuffers"
mapfile -t GOT < <(sed -n 's/^framebuffer \([0-9a-f]*\).*/\1/p' "$LOG")
for i in 0 1 2 3 4 5; do
   check "frame $((i+1))" "${GOT[$i]:-}" "${REF[$i]}"
done

# Phase 2 opens the OK-button form, presses the button, and releases -- which
# closes it, so that frame is the bare gradient again (reference frame 3).
# It then opens test2.l and leaves it up, purely so a screenshot of the page
# shows something; that frame has no native counterpart in this sequence and is
# deliberately not checked.
echo "phase 2 -- index.html through its own listeners"
get() { sed -n "s/^page $1 \\([0-9a-f]*\\)$/\\1/p" "$LOG" | head -1; }
check "blank"    "$(get blank)"    "${REF[2]}"
check "form"     "$(get form)"     "${REF[0]}"
check "pressed"  "$(get pressed)"  "${REF[1]}"
check "released" "$(get released)" "${REF[2]}"

# Drawing from the expression box has no native counterpart to diff against,
# but it must land and must survive the redraw -- i.e. differ from the bare
# gradient.
drew=$(get repl-draw)
if [ -n "$drew" ] && [ "$drew" != "${REF[2]}" ]; then
   printf '  %-22s %s  ok (differs from gradient)\n' "repl-draw" "$drew"
else
   printf '  %-22s %s  EXPECTED something other than %s\n' "repl-draw" "${drew:-<missing>}" "${REF[2]}"
   fail=1
fi

echo
if [ $fail = 0 ]; then
   echo "browser test PASSED  (frames also saved as $OUT/*.png)"
else
   echo "browser test FAILED"
fi
exit $fail
