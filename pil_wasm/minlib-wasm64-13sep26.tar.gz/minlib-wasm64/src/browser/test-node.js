// Headless driver for the browser build: calls exactly the exports index.html
// calls, so the wasm side can be verified without a browser. It does not cover
// the page's DOM wiring -- check that in a real browser.
//
// Prints a framebuffer digest in the same format as src/stubgui.c, so the
// output can be diffed against the native reference.

const createPil = require('../../bin/web/picolisp.js');

const W = 800, H = 600;

function digest(Module, base) {
   // FNV-1a over the pixel buffer, plus the count of pixels the GUI changed.
   const px = new Uint8Array(Module.HEAPU8.buffer, Number(base), W * H * 4);
   let h = 0xcbf29ce484222325n;
   const M = (1n << 64n) - 1n;
   for (let i = 0; i < px.length; ++i)
      h = ((h ^ BigInt(px[i])) * 0x100000001b3n) & M;
   const u32 = new Uint32Array(Module.HEAPU8.buffer, Number(base), W * H);
   let drawn = 0, x0 = W, y0 = H, x1 = -1, y1 = -1;
   for (let y = 0; y < H; ++y)
      for (let x = 0; x < W; ++x) {
         const r = (x * 255 / W) | 0, g = (y * 255 / H) | 0;
         const bg = (((255 << 24) | (40 << 16) | (g << 8) | r) >>> 0);
         if (u32[y * W + x] !== bg) {
            ++drawn;
            if (x < x0) x0 = x;
            if (x > x1) x1 = x;
            if (y < y0) y0 = y;
            if (y > y1) y1 = y;
         }
      }
   let s = `framebuffer ${h.toString(16).padStart(16, '0')}  ${drawn} drawn`;
   if (x1 >= 0) s += `  bbox ${x0},${y0}..${x1},${y1}`;
   console.log(s);
}

createPil().then(Module => {
   // The suspending calls are void; results come back through the getters.
   const pilStart  = Module.cwrap('pilStart', null, ['number', 'number']);
   const pilEval   = Module.cwrap('pilEval', null, ['string']);
   const pilFrame  = Module.cwrap('pilFrame', null, []);
   const pilStop   = Module.cwrap('pilStop', null, []);
   const pilReady  = Module.cwrap('pilReady', 'number', []);
   const pilPixels = Module.cwrap('pilPixels', 'number', []);
   const pilResult = Module.cwrap('pilResult', 'string', []);

   pilStart(W, H);
   console.log('pilStart -> ready =', pilReady());
   if (!pilReady()) process.exit(1);
   const base = pilPixels();

   const ev = (what, expr) => {
      pilEval(expr);
      console.log(`${what.padEnd(6)} ${expr.padEnd(44)} -> ${pilResult()}`);
   };

   ev('form', '(co \'gui (fonts "FreeSansB") (form 2 3 6 5 (1 1 (okButton))))');
   pilFrame();  digest(Module, base);

   ev('down', '(fbDn 110 139)');
   pilFrame();  digest(Module, base);

   ev('click', '(fbClick 110 139)');
   ev('up', '(fbUp 110 139)');
   pilFrame();  digest(Module, base);

   ev('load1', '(co \'gui (load "test1.l"))');
   pilFrame();  digest(Module, base);

   ev('key', '(fbKey "x")');
   pilFrame();  digest(Module, base);

   ev('stop', '(co \'gui)');
   ev('load2', '(co \'gui (load "test2.l"))');
   pilFrame();  digest(Module, base);

   pilStop();
   console.log('done');
});
