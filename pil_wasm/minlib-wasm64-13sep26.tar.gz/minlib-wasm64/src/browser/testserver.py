#!/usr/bin/env python3
"""Serve bin/web and collect what the browser reports back.

A headless screenshot alone cannot tell you whether the wasm module ever
finished loading -- Firefox's --screenshot fires around the load event and
exits, long before a 1.9 MB Asyncify module has initialised and drawn. So
selftest.html reports each step with fetch() and uploads the rendered canvas,
and this server writes both to disk.

    python3 testserver.py [port] [outdir]

Then, in another shell:

    firefox --headless --no-remote --profile /tmp/ffprof \
            http://127.0.0.1:<port>/selftest.html &
    sleep 25 && kill %1
    cat <outdir>/selftest.log
"""

import http.server
import os
import sys
import time
import urllib.parse

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8791
OUT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/minlib-browser"
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "bin", "web")


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def log_message(self, *a):
        pass                                   # the selftest log is the signal

    def _ok(self, body=b""):
        self.send_response(200)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        # Firefox's --screenshot fires around the load event, long before a
        # 1.9 MB Asyncify module has initialised and drawn. selftest.html asks
        # for this resource, and holding it open keeps the load event pending
        # until the run reports DONE -- so the screenshot captures the finished
        # page instead of a blank canvas.
        if self.path.startswith("/hold/"):
            log = os.path.join(OUT, "selftest.log")
            for _ in range(600):
                try:
                    if "DONE" in open(log).read():
                        break
                except OSError:
                    pass
                time.sleep(0.1)
            # A 1x1 transparent GIF, so the page can use it as an <img>.
            return self._ok(bytes.fromhex(
                "47494638396101000100800000000000ffffff21f90401000000"
                "002c00000000010001000002024401003b"))
        if self.path.startswith("/selftest/"):
            # /selftest/<seq>/<percent-encoded line>. The sequence number is
            # kept because fetch() does not preserve ordering.
            rest = self.path[len("/selftest/"):]
            seq, _, enc = rest.partition("/")
            line = urllib.parse.unquote(enc)
            with open(os.path.join(OUT, "selftest.log"), "a") as f:
                f.write(f"{int(seq):04d} {line}\n")
            print(line, flush=True)
            return self._ok()
        super().do_GET()

    def do_POST(self):
        if self.path.startswith("/shot/"):
            name = os.path.basename(self.path[len("/shot/"):]) or "shot"
            data = self.rfile.read(int(self.headers.get("Content-Length", 0)))
            path = os.path.join(OUT, name + ".png")
            with open(path, "wb") as f:
                f.write(data)
            print(f"[saved {path} {len(data)} bytes]", flush=True)
            return self._ok()
        self.send_error(404)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    open(os.path.join(OUT, "selftest.log"), "w").close()
    print(f"serving {os.path.normpath(ROOT)} on {PORT}, collecting into {OUT}",
          flush=True)
    http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
