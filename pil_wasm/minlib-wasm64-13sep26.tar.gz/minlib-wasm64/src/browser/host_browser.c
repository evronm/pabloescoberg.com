// Browser front end for minlib: the framebuffer GUI on a canvas.
//
// Mirrors sdl2gui.c's contract -- picolisp(), ssfn(pixels, w, h), then
// evaluate("(fbDraw)") after every event -- but leaves the pixel buffer in
// linear memory where JS can view it directly as canvas ImageData.
// SDL_PIXELFORMAT_ABGR8888 is byte-identical to canvas RGBA on little-endian,
// so nothing has to be converted.
//
// Why nothing here returns a value:
//
// Any call that reaches a fiber swap unwinds out to the JS boundary and is
// rewound by Emscripten's fiber trampoline. The work completes within the
// original JS call, but the *return value* does not survive the round trip --
// JS sees the dummy value from the unwinding return, not the real one. So the
// suspending entry points are all void, and results are picked up afterwards
// through plain getters that cannot suspend.

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <emscripten.h>

#include "../host.h"   // for Pil_InBye

int picolisp(char*, int, int, char**);
char *evaluate(char*);
void stoplisp(void);
void ssfn(uint32_t*, int, int);

// The interpreter's stack. With fibers this is also the arena PicoLisp carves
// coroutine stacks out of, so it has to be sized for more than one: lib/gui.l
// runs in 'gui, and a form can open further forms. 1 MB (what sdl2gui.c
// passes) holds about a dozen at the default 64 kB $StkSize.
static char Stack[8 * 1024 * 1024];

static uint32_t *Pixels;
static int W, H, Ready;
static char *Result;

// --- suspending entry points, all void ---

// Debug mode ("+") is deliberately off: it drops into a REPL on stdin, and a
// browser has no usable stdin. "-" terminates the vector instead -- loadAll
// walks $AV until a NULL slot or a bare "-".
EMSCRIPTEN_KEEPALIVE
void pilStart(int w, int h) {
   static char *init[] = {"picolisp", "lib.l", "lib/misc.l", "lib/gui.l",
      "--symbols", "gui", "-"};

   if (Ready || !(Pixels = malloc((size_t)w * h * sizeof(uint32_t))))
      return;
   W = w,  H = h;
   if (!picolisp(Stack, sizeof(Stack), (int)(sizeof(init)/sizeof(char*)), init)) {
      free(Pixels),  Pixels = NULL;
      return;
   }
   ssfn(Pixels, w, h);
   Ready = 1;
}

// Has the interpreter torn itself down? See the note on Pil_InBye in host.h.
//
// This has to be checked on *entry*, not after the evaluation: when the
// interpreter calls exit(), the fiber trampoline returns to JS rather than
// resuming us, so nothing after evaluate() ever runs. By the next call in,
// $InBye is set and we are on a fresh JS call, so it is visible then.
//
// Going not-Ready turns every later call into a no-op, which lets the page
// report it instead of crashing on a half-dismantled interpreter.
static int alive(void) {
   if (Pil_InBye)
      Ready = 0;
   return Ready;
}

EMSCRIPTEN_KEEPALIVE
void pilEval(const char *expr) {
   if (alive()) {
      free(Result);
      Result = evaluate((char*)expr);
   }
}

// One frame: sdl2gui.c's background gradation, then let lib/gui.l draw over it.
EMSCRIPTEN_KEEPALIVE
void pilFrame(void) {
   if (!alive())
      return;
   for (int y = 0; y < H; ++y)
      for (int x = 0; x < W; ++x) {
         uint8_t r = (uint8_t)(x * 255 / W);
         uint8_t g = (uint8_t)(y * 255 / H);
         Pixels[y * W + x] = (255u << 24) | (40u << 16) | ((uint32_t)g << 8) | r;
      }
   free(Result);
   // Caught, so that an error while drawing cannot tear the interpreter down.
   Result = evaluate("(catch '(NIL) (fbDraw))");
}

EMSCRIPTEN_KEEPALIVE
void pilStop(void) {
   if (alive()) {
      Ready = 0;
      ssfn(NULL, 0, 0);
      stoplisp();
   }
}

// --- getters, which never suspend ---

EMSCRIPTEN_KEEPALIVE int pilReady(void) { return alive(); }
EMSCRIPTEN_KEEPALIVE uint32_t *pilPixels(void) { return Pixels; }
EMSCRIPTEN_KEEPALIVE const char *pilResult(void) { return Result ? Result : ""; }
