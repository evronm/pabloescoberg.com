// Prototype B: inverted control. No stack switching at all, so no Asyncify.
//
// picolisp() does not return until the host says quit. Instead of the host
// calling evaluate(), the interpreter asks the host for work: hostYield() calls
// pilHostRequest(), handing back the previous result and receiving the next
// expression, or NULL to quit.
//
// This is the portable option -- it needs nothing from the platform beyond a
// plain call -- but it changes the published ABI: evaluate() and reflect() no
// longer exist, and the host must supply pilHostRequest(). It also does nothing
// for PicoLisp's coroutines, which relocate the stack independently in flow.l.
//
// In a browser it buys less than it looks like it does: with the driving loop
// inside wasm there is no way to yield to the event loop, so an interactive GUI
// would still need Asyncify or JSPI.

#include <stdlib.h>
#include "host.h"

// Supplied by the host.
char *pilHostRequest(char *result);

int hostYield(void) {
   char *expr;

   if (!(expr = pilHostRequest((char*)Pil_Ret)))
      return PIL_QUIT;
   Pil_Ret = (uint64_t)expr;
   return PIL_EVALUATE;
}

int picolisp(char *stack, int size, int ac, char **av) {
   return lispMain(stack, size, ac, av);
}

// Not part of this prototype's ABI: there is no suspended interpreter to
// re-enter from the outside.
char *evaluate(char *expr) { return NULL; }
void reflect(char *adr, char *str) {}
