// Native hand-over: setjmp/longjmp, exactly the mechanism upstream main.l used.
//
// This file exists to show the refactor is behaviour-preserving. The bounce is
// unchanged -- it is only expressed in C now, so that a platform which cannot
// resume a returned frame can substitute a different hostYield().
//
// It still depends on the caller-supplied stack buffer staying live after
// picolisp() returns, because YieldRst's frame is inside it. That is the
// assumption wasm breaks.

#include <stdlib.h>
#include "host.h"

static jmp_buf YieldRst;   // interpreter's resume point, inside hostYield()
static int Cmd;            // command for the interpreter
static int Started;

// --- interpreter side ---

int hostYield(void) {
   if (!setjmp(YieldRst))
      longjmp(SoRst, 1);   // hand control to the host
   return Cmd;             // resumed by the host
}

// --- host side ---

static void toLisp(int cmd) {
   Cmd = cmd;
   longjmp(YieldRst, 1);
}

int picolisp(char *stack, int size, int ac, char **av) {
   if (setjmp(SoRst))      // the interpreter handed control back
      return Started = 1;
   return lispMain(stack, size, ac, av);   // returns only on failure
}

char *evaluate(char *expr) {
   if (!Started)
      return NULL;
   if (setjmp(SoRst))
      return (char*)Pil_Ret;
   Pil_Ret = (uint64_t)expr;
   toLisp(PIL_EVALUATE);
   return NULL;            // not reached
}

void reflect(char *adr, char *str) {
   if (!Started || !hostReflect(adr, str))
      return;
   if (setjmp(SoRst))
      return;
   toLisp(PIL_REFLECT);
}
