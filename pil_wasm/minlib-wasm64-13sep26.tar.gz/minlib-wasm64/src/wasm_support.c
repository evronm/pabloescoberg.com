// Support code for the minlib wasm64 build. Additive: nothing in minlib's own
// sources is modified, and lib.so.c is not forked.

#include <stdlib.h>
#include <string.h>

#ifdef __EMSCRIPTEN__
#include <emscripten/heap.h>
#endif

// 16-byte aligned replacement for realloc, used only by main.l's heapAlloc().
//
// PicoLisp tags values in the low 4 bits of a pointer, so heap cells must be
// 16-byte aligned; Emscripten's wasm64 malloc guarantees only 8. See the
// commentary in wasm_patch_ll.py for why the IR renames @realloc to reach this
// rather than using -Wl,--wrap=realloc.
//
// emscripten_builtin_memalign() is used rather than aligned_alloc() because it
// bypasses --wrap indirection and so cannot recurse.
//
// heapAlloc() only ever calls this as realloc(NULL, n), i.e. as an aligned
// malloc, but the grow path is implemented anyway so the semantics stay honest.
void *__pil_realloc(void *ptr, size_t size) {
#ifdef __EMSCRIPTEN__
   void *new;

   if (!(new = emscripten_builtin_memalign(16, size)))
      return NULL;
   if (ptr) {
      // No portable way to recover the old size; heapAlloc() never takes this
      // path, so copying `size` bytes is safe in practice only because the
      // block always grows. Guard it if a caller ever shrinks a block.
      memcpy(new, ptr, size);
      free(ptr);
   }
   return new;
#else
   // Native build of the patched IR, used to prove the IR patch is
   // semantically neutral before introducing wasm.
   return realloc(ptr, size);
#endif
}
