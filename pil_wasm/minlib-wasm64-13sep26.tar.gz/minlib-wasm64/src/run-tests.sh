#!/bin/bash
# Compare every build against the upstream native reference on the same suite.
# Run from src/ after `make -f Makefile.wasm PIL=~/src/pil21 test`.

set -e
BIN=../bin
OUT=/tmp/minlib-test
mkdir -p $OUT

evals() { grep '^eval' "$1" || true; }

run() { # name command...
   name=$1; shift
   "$@" > $OUT/$name.out 2>&1 || true
   printf '%-24s %2d/%-2d expressions' "$name" "$(evals $OUT/$name.out | grep -c ' -> ')" "$TOTAL"
   # A build may stop early (fine, reported as a count) but every line it does
   # produce must match the reference. A '>' in the diff means it printed
   # something the reference did not -- a wrong answer, not truncation.
   if diff -q <(evals $OUT/reference.out) <(evals $OUT/$name.out) >/dev/null 2>&1; then
      echo "   IDENTICAL to native"
   elif diff <(evals $OUT/reference.out) <(evals $OUT/$name.out) | grep -q '^>'; then
      echo "   *** WRONG OUTPUT ***"
   else
      echo "   correct as far as it got"
   fi
}

$BIN/stubhost-upstream > $OUT/reference.out 2>&1
TOTAL=$(evals $OUT/reference.out | grep -c ' -> ')
printf '%-24s %2d/%-2d expressions   (native reference)\n' reference $TOTAL $TOTAL

echo
echo "--- controls: the IR patch and the main.l refactor must change nothing ---"
run stub-native    $BIN/stubhost-patched
run native-setjmp  $BIN/stubhost-refactor

echo
echo "--- milestone 1: upstream ABI on wasm64 ---"
run wasm-upstream     node $BIN/stubhost.js
run wasm-upstream-eh  node $BIN/stubhost.eh.js

echo
echo "--- prototypes ---"
run fiber       node $BIN/stubhost.fib.js
run inverted    node $BIN/stubhost.inv.js
run coroutines  node $BIN/stubhost.crt.js

echo
echo "--- lib/gui.l rendered headless: the framebuffer itself ---"
$BIN/stubgui-upstream > $OUT/gui-native.out 2>&1 || true
node $BIN/stubgui.crt.js > $OUT/gui-wasm.out 2>&1 || true
printf '%-24s %2d framebuffers' gui-native "$(grep -c '^framebuffer' $OUT/gui-native.out)"
echo "   (native reference)"
printf '%-24s %2d framebuffers' gui-wasm64 "$(grep -c '^framebuffer' $OUT/gui-wasm.out)"
if diff -q $OUT/gui-native.out $OUT/gui-wasm.out >/dev/null 2>&1; then
   echo "   IDENTICAL to native"
else
   echo "   *** DIFFERS from native ***"
fi

echo
echo "--- module sizes ---"
ls -l $BIN/*.wasm 2>/dev/null | awk '{printf "%-34s %6.0f KB\n", $9, $5/1024}'
