#!/usr/bin/env python3
"""Post-process minlib's base.so.ll for wasm64.

Two transformations, both forced by wasm semantics that x86_64 happens to be
lax about. Derived from the earlier pil21 wasm64 port (~/src/pil21/HANDOFF.md),
but much smaller: see "What no longer applies" at the bottom.

1. Builtin dispatch signature mismatch.

   llvm.l's subr dispatch loads a function address out of @$JumpTab and calls
   it as i64(i64,i64) -- passing (Exe, Fun). But every builtin except __Meth is
   defined as i64(i64), taking Exe alone. x86_64 silently ignores the extra
   argument; wasm's call_indirect compares the callee's runtime type against the
   call site's static type and traps on mismatch.

   Fix: give every one-arg builtin a dummy second i64 parameter, so its real
   type matches the dispatch. Unnamed LLVM parameters occupy %0, %1, ..., so the
   whole body has to be renumbered by one. The JumpTab's bitcast operand types
   and the handful of direct call sites are updated to match.

2. Heap segment alignment.

   PicoLisp tags values in the low 4 bits of a pointer (pico.h: atom(x) = x&15,
   sym(x) = x&8), so cells must be 16-byte aligned. main.l's heapAlloc() takes
   each segment from alloc(null, 8 * (HEAP + 1)) -> realloc, and Emscripten's
   wasm64 malloc is only 8-byte aligned. A segment landing on an 8-mod-16
   address sets bit 3 on every cell in it, so every cell pointer reads back as
   a symbol and the interpreter hangs or prints garbage. Because it depends on
   nothing but preceding allocation history, the failure looks nondeterministic
   and moves with any unrelated change -- this cost the pil21 port weeks.

   Fix: rename @realloc to @__pil_realloc and implement that in wasm_support.c
   over emscripten_builtin_memalign(16, ...). The rename is required, not
   cosmetic: at -O2 LLVM folds realloc(NULL, n) into malloc(n), so
   -Wl,--wrap=realloc never sees the heap segment at all. Wrapping malloc
   itself is not an option either -- it breaks Emscripten's own malloc export.

What no longer applies, versus pil21's wasm_patch_ll.py:

  - No @$FuncPtrTable. pil21's SymTab held tagged function addresses (+2, untag
    with & ~3), which is incompatible with wasm's sequential table indices, so
    the port had to synthesize a memory indirection table. The current llvm.l
    instead keeps addresses in @$JumpTab and stores small indices in SymTab --
    that *is* the indirection, and it is layout-independent by construction. No
    SymTab rewriting and no dispatch patching are needed.
  - No @poll rename. minlib's dec.l declares no poll/fread/fwrite at all.

_putStdout/_getStdin are deliberately left alone: they are stored into $Put/$Get
as properly typed function pointers (void(i8)*, i32()*), which wasm handles
natively, and console interception is done at link time with -Wl,--wrap.
"""

import re
import sys

# define i64 @_Foo(i64) align 8 {
ONE_ARG_DEF = re.compile(r'^define i64 @(_\w+)\(i64\) align 8 \{')

# @$JumpTab entry: i64 ptrtoint (i8* bitcast (i64(i64)* @_Foo to i8*) to i64)
JUMPTAB_REF = re.compile(r'bitcast \(i64\(i64\)\* @(_\w+) to i8\*\)')

# %1 = call i64 @_Foo(i64 %0)
DIRECT_CALL = re.compile(r'call i64 @(_\w+)\(i64 ([^,()]+)\)')

# The entry point from the patched main.l, whose (stack ...) has to go.
LISPMAIN_DEF = re.compile(r'^define i1 @lispMain\(')


def renumber_line(line):
    """Shift unnamed SSA values %N -> %N+1 for N >= 1.

    Block labels are %$N in this IR, so the negative lookbehind on '$' keeps
    them untouched; %0 stays put because it is the first (real) parameter.
    """
    def bump(m):
        n = int(m.group(2))
        return m.group(1) + '%' + str(n + 1) if n >= 1 else m.group(0)
    return re.sub(r'((?:^|[^$]))%(\d+)', bump, line)


def main():
    # With -sSUPPORT_LONGJMP=wasm, LLVM refuses to lower setjmp/longjmp in a
    # function that does not advertise +exception-handling. Clang adds that from
    # the command line, but these definitions come from hand-written IR, so the
    # attribute has to be attached here.
    wasm_exceptions = '--wasm-exceptions' in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if len(args) != 2:
        print(f"usage: {sys.argv[0]} [--wasm-exceptions] input.ll output.ll",
              file=sys.stderr)
        return 1

    with open(args[0]) as f:
        lines = f.readlines()

    one_arg = {m.group(1) for m in map(ONE_ARG_DEF.match, lines) if m}
    if not one_arg:
        print(f"{sys.argv[0]}: no one-arg builtins found -- has llvm.l's "
              f"calling convention changed?", file=sys.stderr)
        return 1

    out = []
    in_one_arg = in_lispmain = False
    n_jumptab = n_calls = n_stack = 0

    for line in lines:
        line = line.replace('@realloc(', '@__pil_realloc(')

        # A JumpTab bitcast names the callee's type, so it has to track the
        # signature change or the module no longer verifies.
        def fix_jumptab(m):
            nonlocal n_jumptab
            if m.group(1) not in one_arg:
                return m.group(0)
            n_jumptab += 1
            return f'bitcast (i64(i64,i64)* @{m.group(1)} to i8*)'
        line = JUMPTAB_REF.sub(fix_jumptab, line)

        attr = ' #0' if wasm_exceptions else ''

        m = ONE_ARG_DEF.match(line)
        if m:
            out.append(line.replace('(i64) align 8 {',
                                    f'(i64, i64) align 8{attr} {{'))
            in_one_arg = True
            continue

        if line.startswith('define '):
            if attr and line.rstrip().endswith('align 8 {'):
                line = line.replace('align 8 {', f'align 8{attr} {{')
            in_one_arg = False
            in_lispmain = bool(LISPMAIN_DEF.match(line))
        elif in_one_arg:
            if line.rstrip() == '}':
                in_one_arg = False
            else:
                line = renumber_line(line)

        # lispMain's (stack (ofs Stk Siz)) relocates the machine stack pointer
        # into the host-supplied buffer. On wasm that would only move
        # Emscripten's shadow stack pointer, and whichever host_*.c is linked
        # owns it -- host_fiber.c hands the interpreter a fiber whose C stack is
        # that buffer already, and host_inverted.c leaves it alone. Either way
        # the relocation is wrong here, so drop it. The neighbouring
        # $StkLimit/$SysStkLimit stores are kept: Stk/Siz still describe the
        # stack in use, so the overflow low-water mark stays meaningful.
        #
        # Scoped to lispMain on purpose: flow.l uses stackrestore for
        # coroutines, and those are a separate (still unsolved) problem.
        if in_lispmain and 'call void @llvm.stackrestore(' in line:
            n_stack += 1
            out.append('  ; # (stack ...) removed for wasm by wasm_patch_ll.py\n')
            continue

        # Direct calls now have to pass the dummy argument too.
        def fix_call(m):
            nonlocal n_calls
            if m.group(1) not in one_arg:
                return m.group(0)
            n_calls += 1
            return f'call i64 @{m.group(1)}(i64 {m.group(2)}, i64 0)'
        line = DIRECT_CALL.sub(fix_call, line)

        out.append(line)

    if wasm_exceptions:
        out.append('\nattributes #0 = { "target-features"="+exception-handling" }\n')

    with open(args[1], 'w') as f:
        f.writelines(out)

    print(f"wasm_patch_ll: {len(one_arg)} builtins given a dummy second "
          f"argument, {n_jumptab} JumpTab entries and {n_calls} direct calls "
          f"retyped, {n_stack} stackrestore removed", file=sys.stderr)
    return 0


if __name__ == '__main__':
    sys.exit(main())
