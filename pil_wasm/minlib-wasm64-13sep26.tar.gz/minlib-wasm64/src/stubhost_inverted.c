// Stub host for prototype B (inverted control).
//
// Runs the identical suite from test_exprs.h and prints it in the same format
// as stubhost.c, so the `eval` lines can be diffed against the native
// reference. The framing lines necessarily differ: here picolisp() does not
// return until the suite is done.

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "test_exprs.h"

int picolisp(char *stack, int size, int ac, char **av);

static char Stack[1024 * 1024];
static int Next;

// Called by the interpreter: `result` is the previous expression's value (or
// garbage on the first call, which we ignore), and we return the next
// expression to evaluate, or NULL to quit.
char *pilHostRequest(char *result) {
   if (Next) {
      printf(" -> %s\n", result ? result : "(null)");
      fflush(stdout);
      free(result);   // evaluate()'s contract: the result is strdup'd
   }
   if (!TestExprs[Next]) {
      printf("host asked to quit\n");
      fflush(stdout);
      return NULL;
   }
   printf("eval  %-34s", TestExprs[Next]);
   fflush(stdout);
   return (char*)TestExprs[Next++];
}

int main(void) {
   static char *init[] = {"stubhost", "lib.l", "-"};

   printf("calling picolisp() -- it will not return until the suite is done\n");
   fflush(stdout);
   if (!picolisp(Stack, sizeof(Stack), (int)(sizeof(init)/sizeof(char*)), init)) {
      fprintf(stderr, "picolisp() failed\n");
      return 1;
   }
   printf("picolisp() returned\n");
   return 0;
}
