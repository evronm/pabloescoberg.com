// Prototype A: hand-over by Emscripten fiber swap. wasm64.
//
// Keeps minlib's published C ABI exactly: picolisp() initialises and returns,
// evaluate() is callable afterwards, stoplisp() tears down.
//
// The interpreter runs on its own fiber whose C stack is carved from the
// caller-supplied buffer -- which is what the ABI's `char *stack` argument was
// always for. Because that fiber is suspended rather than returned from, its
// frames stay live, so there is nothing to resurrect: hostYield() swaps to the
// host and, when the host swaps back, simply returns the next command.
//
// Costs -sASYNCIFY. Emscripten's fiber support is built on it, and Asyncify
// instruments (nearly) the whole module, so expect a large size and speed hit.
//
// The Asyncify stacks are malloc'd rather than taken from the caller's buffer,
// so the interpreter still gets the full stack the host offered it.

#include <stdlib.h>
#include <stdio.h>
#include <emscripten/fiber.h>
#include "host.h"

#define ASYNCIFY_STACK (1024 * 1024)

static emscripten_fiber_t HostFiber, LispFiber;
static int Cmd, Started, Done, Result;
static char *Stk, **Av;
static int Siz, Ac;

// src/crt_fiber.c borrows this for PicoLisp's "main" coroutine: that coroutine
// is not a fiber we create, it *is* the context the interpreter already runs
// on, and two handles describing one stack would be a latent trap.
emscripten_fiber_t *pilHostSideFiber(void) {
   return Started ? &LispFiber : NULL;
}

// --- interpreter side, runs on LispFiber ---

int hostYield(void) {
   emscripten_fiber_swap(&LispFiber, &HostFiber);   // hand control to the host
   return Cmd;                                      // host swapped back
}

static void lispEntry(void *arg) {
   Result = lispMain(Stk, Siz, Ac, Av);   // returns on load failure or PIL_QUIT
   Done = 1;
   emscripten_fiber_swap(&LispFiber, &HostFiber);
}

// --- host side, runs on HostFiber ---

static int toLisp(int cmd) {
   if (!Started || Done)
      return 0;
   Cmd = cmd;
   emscripten_fiber_swap(&HostFiber, &LispFiber);
   return 1;
}

int picolisp(char *stack, int size, int ac, char **av) {
   void *hostAsyncify, *lispAsyncify;

   if (!(hostAsyncify = malloc(ASYNCIFY_STACK)) ||
       !(lispAsyncify = malloc(ASYNCIFY_STACK)))
      return 0;

   // (stack ...) is patched out of lispMain for wasm -- the fiber owns the
   // stack pointer. Stk/Siz still describe that stack, so main.l's
   // $StkLimit/$SysStkLimit low-water mark stays meaningful.
   Stk = stack,  Siz = size,  Ac = ac,  Av = av;

   emscripten_fiber_init_from_current_context(&HostFiber, hostAsyncify, ASYNCIFY_STACK);
   emscripten_fiber_init(&LispFiber, lispEntry, NULL, stack, (size_t)size,
      lispAsyncify, ASYNCIFY_STACK);

   Started = 1;
   emscripten_fiber_swap(&HostFiber, &LispFiber);   // run init, up to first yield
   return Done ? Result : 1;
}

char *evaluate(char *expr) {
   Pil_Ret = (uint64_t)expr;
   return toLisp(PIL_EVALUATE) ? (char*)Pil_Ret : NULL;
}

void reflect(char *adr, char *str) {
   if (Started && !Done && hostReflect(adr, str))
      toLisp(PIL_REFLECT);
}
