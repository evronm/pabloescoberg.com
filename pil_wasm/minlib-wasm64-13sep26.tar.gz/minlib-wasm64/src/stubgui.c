// Headless GUI host: milestone 4 without a window.
//
// Follows sdl2gui.c's contract exactly -- same init vector, same gradient
// background, same (fbDraw) call -- but renders into a plain buffer and prints
// a digest of it instead of blitting. That makes the framebuffer comparable
// between the native build and wasm64: identical digests mean lib/gui.l drew
// the same pixels, which is the whole of milestone 4 minus the canvas.

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define FB_WIDTH  800
#define FB_HEIGHT 600

int picolisp(char*, int, int, char**);
char *evaluate(char*);
void stoplisp(void);
void ssfn(uint32_t*, int, int);

static char Stack[1024 * 1024];
static uint32_t *Pixels;

static void banner(const char *what, const char *expr) {
   char *res;

   printf("%-6s %-44s", what, expr);
   fflush(stdout);
   res = evaluate((char*)expr);
   printf(" -> %s\n", res ? res : "(null)");
   fflush(stdout);
   free(res);
}

// sdl2gui.c's background, so the digest covers the same starting pixels.
static void background(void) {
   for (int y = 0; y < FB_HEIGHT; ++y)
      for (int x = 0; x < FB_WIDTH; ++x) {
         uint8_t r = (uint8_t)(x * 255 / FB_WIDTH);
         uint8_t g = (uint8_t)(y * 255 / FB_HEIGHT);
         Pixels[y * FB_WIDTH + x] = (255 << 24) | (40 << 16) | (g << 8) | r;
      }
}

// FNV-1a over the buffer, plus a count of pixels the GUI changed, so a digest
// mismatch says something about *how* the two runs differ.
static void digest(void) {
   uint64_t h = 0xcbf29ce484222325ULL;
   long drawn = 0;
   const uint8_t *p = (const uint8_t*)Pixels;

   for (long i = 0; i < (long)FB_WIDTH * FB_HEIGHT * 4; ++i)
      h = (h ^ p[i]) * 0x100000001b3ULL;
   for (long y = 0; y < FB_HEIGHT; ++y)
      for (long x = 0; x < FB_WIDTH; ++x) {
         uint8_t r = (uint8_t)(x * 255 / FB_WIDTH);
         uint8_t g = (uint8_t)(y * 255 / FB_HEIGHT);
         if (Pixels[y * FB_WIDTH + x] != (uint32_t)((255 << 24) | (40 << 16) | (g << 8) | r))
            ++drawn;
      }
   // Bounding box of the drawn area, so a mismatch localises, and so a click
   // can be aimed at whatever the GUI actually put on screen.
   long x0 = FB_WIDTH, y0 = FB_HEIGHT, x1 = -1, y1 = -1;
   for (long y = 0; y < FB_HEIGHT; ++y)
      for (long x = 0; x < FB_WIDTH; ++x) {
         uint8_t r = (uint8_t)(x * 255 / FB_WIDTH);
         uint8_t g = (uint8_t)(y * 255 / FB_HEIGHT);
         if (Pixels[y * FB_WIDTH + x] != (uint32_t)((255 << 24) | (40 << 16) | (g << 8) | r)) {
            if (x < x0) x0 = x;
            if (x > x1) x1 = x;
            if (y < y0) y0 = y;
            if (y > y1) y1 = y;
         }
      }
   printf("framebuffer %016llx  %ld drawn", (unsigned long long)h, drawn);
   if (x1 >= 0)
      printf("  bbox %ld,%ld..%ld,%ld", x0, y0, x1, y1);
   printf("\n");
   fflush(stdout);
#ifndef __EMSCRIPTEN__
   // Native only, for eyeballing what the digest is a digest of.
   if (getenv("PIL_FB_PPM")) {
      FILE *f;
      if ((f = fopen(getenv("PIL_FB_PPM"), "wb"))) {
         fprintf(f, "P6\n%d %d\n255\n", FB_WIDTH, FB_HEIGHT);
         for (long i = 0; i < (long)FB_WIDTH * FB_HEIGHT; ++i) {
            uint32_t v = Pixels[i];
            fputc(v & 255, f), fputc((v >> 8) & 255, f), fputc((v >> 16) & 255, f);
         }
         fclose(f);
      }
   }
#endif
}

int main(int ac, char *av[]) {
   // sdl2gui.c's vector, but ending in "-" rather than "+": debug mode drops
   // into a REPL on stdin when an error is not caught, which hangs a headless
   // run. The browser host does the same for the same reason, and the rendered
   // framebuffers are identical either way.
   static char *init[] = {"stubgui", "lib.l", "lib/misc.l", "lib/gui.l",
      "--symbols", "gui", "-"};

   if (!(Pixels = malloc((size_t)FB_WIDTH * FB_HEIGHT * sizeof(uint32_t)))) {
      fprintf(stderr, "no framebuffer\n");
      return 1;
   }
   if (!picolisp(Stack, sizeof(Stack), (int)(sizeof(init)/sizeof(char*)), init)) {
      fprintf(stderr, "Can't start PicoLisp\n");
      return 1;
   }
   ssfn(Pixels, FB_WIDTH, FB_HEIGHT);

   // Expressions on the command line replace the built-in sequence, which
   // makes this usable for probing the GUI the way stubhost.c is for the core
   // language. Works natively and under `node stubgui.crt.js ...`.
   if (ac > 1) {
      while (--ac)
         banner("eval", *++av);
      background();
      banner("draw", "(fbDraw)");
      digest();
      ssfn(NULL, 0, 0);
      stoplisp();
      return 0;
   }

   // README's minimal form. (co 'gui ...) is the part that needs coroutines.
   banner("form", "(co 'gui (fonts \"FreeSansB\") (form 2 3 6 5 (1 1 (okButton))))");
   background();
   banner("draw", "(fbDraw)");
   digest();

   // Press the OK button. Every handler in lib/gui.l does (yield ... 'gui), so
   // this drives yield-into-a-coroutine-by-tag, and okButton's action is
   // (throw 'done ...) from inside that coroutine to a catch outside it -- the
   // cross-coroutine unwind. Both are the paths crt_fiber.c exists for.
   banner("down", "(fbDn 110 139)");
   background();
   banner("draw", "(fbDraw)");
   digest();

   banner("click", "(fbClick 110 139)");
   banner("up", "(fbUp 110 139)");
   background();
   banner("draw", "(fbDraw)");
   digest();

   // test1.l and test2.l, the demo forms shipped in the tarball.
   banner("load1", "(co 'gui (load \"test1.l\"))");
   background();
   banner("draw", "(fbDraw)");
   digest();

   banner("key", "(fbKey \"x\")");
   background();
   banner("draw", "(fbDraw)");
   digest();

   banner("stop", "(co 'gui)");
   banner("load2", "(co 'gui (load \"test2.l\"))");
   background();
   banner("draw", "(fbDraw)");
   digest();

   ssfn(NULL, 0, 0);
   stoplisp();
   printf("done\n");
   return 0;
}
