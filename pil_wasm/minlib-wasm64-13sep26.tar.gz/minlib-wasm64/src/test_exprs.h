// Shared test suite for the stub hosts, so every prototype runs the identical
// list and the outputs can be diffed against the native reference.
//
// Covers CLAUDE.md's test recipe: a feature sweep across the core language, a
// GC-heavy case forcing heap *growth* (each new segment must also come back
// 16-byte aligned), and repeated re-entry to exercise the host/interpreter
// round trip the embedding ABI rests on.

#ifndef PIL_TEST_EXPRS_H
#define PIL_TEST_EXPRS_H

static const char *TestExprs[] = {
   // Feature sweep
   "(+ 1 2)",
   "(* 6 7)",
   "(mapcar '((N) (* N N)) (range 1 5))",
   "(pack \"a\" \"b\" \"c\")",
   "(let L (1 2 3) (cons (car L) (last L)))",
   "(format 12345678901234567890 6)",
   "(** 2 100)",
   "(sort (5 3 9 1 7))",
   "(sym? 'a)",
   "(catch 'err (throw 'err 42))",
   "(and (= 1 1) (< 1 2) T)",

   // GC-heavy, to force heap growth
   "(length (make (for I 200000 (link I))))",
   "(length (sort (make (for I 50000 (link (* I 7919))))))",
   "(length (pack (need 10000 \"x\")))",
   "(gc)",
   "(length (make (for I 200000 (link I))))",

   // Coroutines. lib/gui.l needs (co 'gui ...), so this decides whether the
   // GUI milestone is reachable. The same expression three times starts the
   // coroutine and then resumes it; (co 'tag) with no prg would stop it.
   "(co 'tst (yield 1) (yield 2) 3)",
   "(co 'tst (yield 1) (yield 2) 3)",
   "(co 'tst (yield 1) (yield 2) 3)",

   // Harder coroutine cases: concurrency, nesting, slot reuse through the free
   // list, explicit stop, and unwinding across a coroutine boundary.
   "(co 'a (yield 1) (yield 2) 'a-done)",
   "(co 'b (yield 10) (yield 20) 'b-done)",
   "(co 'a (yield 1) (yield 2) 'a-done)",
   "(co 'b (yield 10) (yield 20) 'b-done)",
   "(co 'a (yield 1) (yield 2) 'a-done)",
   "(co 'b (yield 10) (yield 20) 'b-done)",
   "(co 'outer (yield (co 'inner (yield 'i1) 'i2)) 'o2)",
   "(co 'inner (yield 'i1) 'i2)",
   "(co 'outer (yield 'x) 'o2)",
   "(length (make (for I 30 (link (co 'reuse (* I I))))))",
   "(co 'c (yield 1) 'c-done)",
   "(co 'c)",
   "(co T)",
   "(co 'd (catch 'e (throw 'e 'caught-inside)))",
   "(catch 'x (co 'f (throw 'x 'crossed-out)))",
   "(co 'g (car 'not-a-list))",
   "(co 'h (let N 200 (recur (N) (if (=0 N) 0 (inc (recurse (dec N)))))))",
   "(co T)",

   // Yield from deep inside a coroutine and resume: the worst case for the
   // Asyncify stack, which has to spill every frame below the yield.
   "(co 'y (let N 200 (recur (N) (if (=0 N) (yield 'bottom) (inc (recurse (dec N)))))))",
   "(co 'y (let N 200 (recur (N) (if (=0 N) (yield 'bottom) (inc (recurse (dec N)))))))",
   "(co T)",

   // Eight coroutines suspended at once. The arena comes out of the host's
   // stack buffer, so the ceiling is the host's to set: 1 MB (what sdl2gui.c
   // passes) holds about a dozen at the default 64 kB $StkSize, and overruns
   // it on both native and wasm64 beyond that.
   // Numeric tags, so each one can be named again to stop it: (co T) refuses
   // while any coroutine is merely suspended rather than finished.
   "(length (make (for I 8 (link (co I (yield I))))))",
   "(make (for I 8 (link (co I))))",
   "(co T)",

   // An *error* inside a coroutine, caught outside it: err() unwinds across
   // the boundary, which is a separate path from throw.
   "(catch '(\"Undefined\") (co 'z (nosuchfn)))",
   "(co T)",
   "(catch '(\"Undefined\") (co 'z2 (co 'z3 (nosuchfn))))",

   "(+ 1 2)",
   NULL
};

#endif
