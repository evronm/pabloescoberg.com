// Fiber-per-coroutine-slot: PicoLisp's (co ...) on wasm64.
//
// flow.l implements coroutines by carving a stack region per slot out of one
// big arena, moving the machine stack pointer into it, and setjmp/longjmp'ing
// between slots. On wasm the arena part survives -- it lands on Emscripten's
// shadow stack, which is ordinary addressable memory -- but the control
// transfer cannot: the real call stack lives inside the VM. So only the
// setjmp/longjmp pairs are replaced, by a fiber swap, and every slot keeps the
// stack region flow.l already gave it.
//
// See flow.l.patch. The pairing is:
//
//   setjmp (Src: (rst)) + longjmp (Dst: (rst))   ->  crtSwap(Src, Dst)
//   ... + runCo() on the freshly carved stack    ->  crtStart(Src, Dst, ...)
//   the main coroutine's context                 ->  crtMain(), borrowing the
//                                                    host layer's fiber
//
// Each slot's trailing jmp_buf area (dec.l: `(rst 0 i8)`, sized JmpBufSize)
// holds the fiber state instead of a jmp_buf. It is big enough: 184 bytes on
// wasm64 against 64 for emscripten_fiber_t.
//
// Requires Asyncify, so this pairs with host_fiber.c. Note that it therefore
// rules out the inverted-control host: coroutines need real stack switching
// whatever the host does, so "no Asyncify" was never actually on the table
// once (co ...) is in scope.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <emscripten/fiber.h>
#include "host.h"

// Asyncify stack per coroutine, as a multiple of the coroutine's own C stack.
//
// Unlike the host hand-over, coroutine yields are *not* shallow: (yield) can be
// called from arbitrary depth, and Asyncify has to spill every frame below it.
// Sizing it against the C stack means it tracks $StkSize if a host changes it.
//
// The multiplier is empirical. PicoLisp's own guard ($StkLimit, one 64th of the
// region) stops the recursion at roughly 1300 frames of a default 64 kB stack,
// and 8x covers a yield from that depth with room to spare -- see the
// yield-from-depth cases in test_exprs.h. Too small shows up as an Asyncify
// abort instead of a clean Lisp "Stack overflow".
#define CRT_ASYNCIFY_RATIO 8
#define CRT_MAIN_ASYNCIFY (1024 * 1024)

// Slots are alloca'd in flow.l's arena, so a slot we have not seen before
// holds whatever was last on that stack -- not zeroes. The magic distinguishes
// "this slot already has switching state, reuse it" from "uninitialised
// garbage that must not be dereferenced". Getting this wrong reads a garbage
// pointer as an Asyncify stack, which faults inside the context switch; it only
// looks fine at first because fresh wasm memory happens to be zeroed.
#define CRT_MAGIC 0x50696C4372744631ULL   /* "PilCrtF1" */

typedef struct {
   uint64_t magic;
   emscripten_fiber_t *fiber;   // -> own, or the host layer's for the main coroutine
   emscripten_fiber_t own;
   void *astack;                // Asyncify stack, owned unless borrowed
   size_t asize;
   void *cstack;                // C stack: the region flow.l carved for this slot
   size_t csize;
   int borrowed;
} CrtFiber;

_Static_assert(sizeof(CrtFiber) <= sizeof(jmp_buf),
   "CrtFiber must fit in a coroutine slot's rst area (dec.l: JmpBufSize)");

// Interpreter side, from flow.l. Never returns: it ends in a crtSwap().
void runCo(uint64_t exe, uint64_t tag, void *src, void *dst, uint64_t prg);

// Arguments for the coroutine about to start. A single slot is enough because
// crtStart() swaps to the new fiber synchronously, so only one start is ever
// in flight.
static struct {
   uint64_t exe, tag, prg;
   void *src, *dst;
} Pending;

// A failed Asyncify-stack allocation cannot be reported back into flow.l
// without inventing an error path there, and continuing would corrupt the next
// context switch. Fail loudly instead.
static void *crtAlloc(size_t size) {
   void *p;

   if (!(p = malloc(size))) {
      fputs("Give up: no coroutine stack\n", stderr);
      abort();
   }
   return p;
}

static void crtEntry(void *arg) {
   runCo(Pending.exe, Pending.tag, Pending.src, Pending.dst, Pending.prg);
   abort();   // unreachable: runCo() swaps away and never comes back
}

// The main coroutine is whichever context the interpreter is already running
// on, not one we create.
void crtMain(char *rst) {
   CrtFiber *f = (CrtFiber*)rst;

   memset(f, 0, sizeof *f);
   f->magic = CRT_MAGIC;
   if ((f->fiber = (emscripten_fiber_t*)pilHostSideFiber()))
      f->borrowed = 1;
   else {
      // No host-side fiber (a host that never switched stacks): make one from
      // the current context.
      f->fiber = &f->own;
      f->asize = CRT_MAIN_ASYNCIFY;
      f->astack = crtAlloc(f->asize);
      emscripten_fiber_init_from_current_context(&f->own, f->astack, f->asize);
   }
}

// Attach the stack region flow.l carved for this slot. Called on slot creation
// and again on reuse from the free list, since `lim` doubles as the free-list
// link and so is rewritten each time.
void crtAttach(char *rst, char *stack, uint64_t size) {
   CrtFiber *f = (CrtFiber*)rst;
   size_t want = (size_t)size * CRT_ASYNCIFY_RATIO;
   void *astack = NULL;
   size_t asize = 0;

   // A slot coming back off the free list keeps its Asyncify stack, unless the
   // wanted size has changed.
   if (f->magic == CRT_MAGIC && !f->borrowed && f->asize >= want)
      astack = f->astack,  asize = f->asize;
   else if (f->magic == CRT_MAGIC && !f->borrowed)
      free(f->astack);

   memset(f, 0, sizeof *f);
   f->magic = CRT_MAGIC;
   f->asize = asize ? asize : want;
   f->astack = astack ? astack : crtAlloc(f->asize);
   f->cstack = stack;
   f->csize = (size_t)size;
   f->fiber = &f->own;
}

// A throw whose catch frame lives on another coroutine's stack: 'unwind' has
// already done the bookkeeping, but the frame to land on is over there, so the
// jump has to ride across the context switch. The target fiber is suspended
// inside one of the swaps below, with the catch frame still live above it, so
// it can finish the longjmp locally on arrival.
static char *PendingJmp;

static void crtResumed(void) {
   char *ca;

   if ((ca = PendingJmp)) {
      PendingJmp = NULL;
      longjmp(*(jmp_buf*)ca, 1);
   }
}

void crtSwap(char *srcRst, char *dstRst) {
   emscripten_fiber_swap(((CrtFiber*)srcRst)->fiber, ((CrtFiber*)dstRst)->fiber);
   crtResumed();
}

void crtThrow(char *caRst, char *srcRst, char *dstRst) {
   PendingJmp = caRst;
   crtSwap(srcRst, dstRst);
   abort();   // unreachable: the source coroutine was stopped by 'unwind'
}

void crtStart(char *srcRst, char *dstRst, uint64_t exe, uint64_t tag,
      void *src, void *dst, uint64_t prg) {
   CrtFiber *f = (CrtFiber*)dstRst;

   Pending.exe = exe,  Pending.tag = tag,  Pending.prg = prg;
   Pending.src = src,  Pending.dst = dst;
   emscripten_fiber_init(&f->own, crtEntry, NULL, f->cstack, f->csize,
      f->astack, f->asize);
   emscripten_fiber_swap(((CrtFiber*)srcRst)->fiber, f->fiber);
   crtResumed();
}

// Release a slot's fiber state. The C stack belongs to flow.l's arena, so only
// the Asyncify stack is ours to free.
void crtFree(char *rst) {
   CrtFiber *f = (CrtFiber*)rst;

   if (f->magic != CRT_MAGIC)
      return;                   // never initialised; nothing here is a pointer
   if (!f->borrowed)
      free(f->astack);
   memset(f, 0, sizeof *f);
}
