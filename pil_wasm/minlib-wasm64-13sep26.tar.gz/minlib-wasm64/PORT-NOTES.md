# minlib → wasm64: status

Last updated: 2026-09-12.

## Summary

**All four milestones are done.** minlib's core language, its embedding ABI,
PicoLisp's coroutines and `lib/gui.l` all run on wasm64, byte-identical to the
native build, and the GUI is on a canvas in the browser with zero DOM
bindings.

The one thing that could not work as published was the embedding ABI, because
minlib relies on *relocating and switching the C stack* and wasm permits
neither. That same mechanism turned out to underlie both the
`picolisp()`/`evaluate()` hand-over and `(co ...)`; both are now handled by
moving the control transfer — and only the control transfer — out of the `.l`
sources into C, where a platform can implement it with fibers instead of
`setjmp`/`longjmp`.

| build | expressions | verdict |
| --- | --- | --- |
| native, upstream | 47/47 | reference |
| native, patched IR (control) | 47/47 | identical to reference |
| native, refactored `main.l` (control) | 47/47 | identical to reference |
| wasm64, upstream ABI, emulated setjmp/longjmp | 1/47 | **wrong output** |
| wasm64, upstream ABI, native wasm setjmp/longjmp | 0/47 | hard failure |
| wasm64, prototype A (fibers, no `co`) | 17/47 | correct, then fails at `co` resume |
| wasm64, prototype B (inverted control) | 17/47 | correct, then fails at `co` resume |
| wasm64, **fibers + fiber-per-coroutine-slot** | **47/47** | **identical to reference** |
| **`lib/gui.l` framebuffer, wasm64** | **6/6 framebuffers** | **identical to reference** |
| **browser demo in Firefox 155** | **6/6 + 4/4 framebuffers** | **identical to reference** |

The suite covers a core-language sweep, GC-heavy heap *growth*, repeated
`evaluate()` round trips, and coroutines: nesting, concurrency, slot reuse
through the free list, explicit stop and stop-all, yield from depth, and both
`throw` and runtime *errors* unwinding out of a coroutine.

Reproduce all of it (from `src/`, after `source ~/src/emsdk/emsdk_env.sh`):

    make -f Makefile.wasm PIL=~/src/pil21 test

`src/stubhost.c` also takes expressions on the command line, natively and under
Node, which is the quickest way to probe something:

    node ../bin/stubhost.crt.js "(co 'a (yield 1) 2)"

## Milestone 1: how the published ABI fails

`main.l:1186-1233` is a hand-rolled two-way coroutine. `QuitRst` is the "resume
the interpreter" continuation, `SoRst` is the "return to the host" one, and
control ping-pongs between them. It works natively only because `main.l:1189`
does `(stack (ofs Stk Siz))` — pointing the machine stack pointer at the host's
`char stack[1024*1024]` buffer — so the interpreter's frames live in host-owned
memory that nobody reclaims after `picolisp()` returns.

- **Emscripten's emulated setjmp/longjmp (the default): silently wrong.**
  `evaluate()` returns *its own input, unevaluated*. It does `setjmp(SoRst)` then
  `longjmp(QuitRst, 2)`; `QuitRst`'s frame has returned, so the unwinder finds
  the nearest *live* setjmp — which is `evaluate()`'s own `SoRst` — and takes its
  non-zero path, `return (i8*)$Ret`. `$Ret` is still the input string. No Lisp
  runs at all, and after a few calls the accumulated corruption faults.
- **Native wasm setjmp/longjmp (`-sSUPPORT_LONGJMP=wasm -fwasm-exceptions`):
  hard failure on the first `evaluate()`**, an uncaught wasm exception escaping
  to JS. Same cause, honestly reported.

`picolisp()` itself returns correctly in both cases; that `longjmp(SoRst, 1)`
targets a frame that is still live.

Under wasm, `(stack …)` lowers to `llvm.stackrestore`, which moves only
Emscripten's *shadow* stack pointer. Return addresses live on the VM's internal
call stack, which is not addressable and cannot be relocated or swapped. So no
link flag fixes this.

## The refactor both prototypes share

`src/main.l.patch` (~30 lines, applied at build time so `main.l` and
`src/Makefile` stay pristine) moves the hand-over out of Lisp and into exactly
one C function:

    int hostYield(void);   // hand control to the host, return the next command
                           // 0 = quit, 2 = evaluate the string in $Ret, 3 = reflect

`picolisp()`, `evaluate()` and `reflect()` — the published C ABI — become C
functions over `lispMain()`. Everything platform-specific is now on the C side
of that one call, which is what makes two strategies droppable in behind an
otherwise untouched interpreter.

This is worth proposing upstream on its own merits, independently of wasm: it
takes the platform's stack-juggling assumptions out of `main.l`.
`src/host_setjmp.c` implements the hand-over with the original setjmp/longjmp,
unchanged, and **is byte-identical to upstream on the full suite** — that is the
control proving the refactor costs nothing.

One IR change goes with it: `wasm_patch_ll.py` deletes the
`llvm.stackrestore` inside `lispMain`, because on wasm whichever `host_*.c` is
linked owns the stack pointer. The neighbouring `$StkLimit`/`$SysStkLimit`
stores are deliberately kept — `Stk`/`Siz` still describe the stack actually in
use (prototype A hands the interpreter a fiber whose C stack *is* the host
buffer), so the overflow low-water mark checked at `dec.l:272` stays meaningful.

## Prototype A — Emscripten fibers (`src/host_fiber.c`)

The interpreter runs on its own fiber whose C stack is carved from the
caller-supplied buffer, which is what the ABI's `char *stack` argument was
always for. Because the fiber is *suspended* rather than returned from, its
frames stay live, so there is nothing to resurrect: `hostYield()` swaps to the
host, and when the host swaps back it simply returns the next command.

- **Keeps the published ABI exactly.** `picolisp()` initialises and returns,
  `evaluate()` is callable afterwards, `stoplisp()` tears down. `sdl2gui.c`'s
  contract is unchanged.
- **Byte-identical to native** on all 17 expressions it reaches — the whole
  feature sweep *and* every GC-growth case (200k-element `make`, `sort`,
  `pack`, explicit `gc`, then another 200k `make`). That also confirms the
  16-byte heap alignment fix works across heap *growth*, which was the pil21
  port's most expensive bug.
- **Costs Asyncify**, but far less than the pil21 port suggested. See
  "Recommendation" below for the numbers and why.

On its own — without the coroutine work below — this reaches 17 of the 47
expressions and then stops at `(co ...)`, which is what motivated the rest.

## Prototype B — inverted control (`src/host_inverted.c`)

`picolisp()` does not return until the host says quit; the interpreter asks the
host for work through a `pilHostRequest()` callback. No stack switching, no
Asyncify, nothing needed from the platform beyond a plain call.

- **Changes the published ABI.** `evaluate()` and `reflect()` cannot exist —
  there is no suspended interpreter to re-enter from the outside — and the host
  must supply `pilHostRequest()` and must not call `stoplisp()` itself.
- **Byte-identical to native** on the same 17 expressions, and 219 KB smaller
  than A.
- **Buys less than it appears to.** With the driving loop inside wasm there is
  no way to yield to the browser event loop, so an interactive GUI would need
  Asyncify or JSPI anyway — which is prototype A's dependency, without
  prototype A's compatibility.

## Coroutines: fiber per slot

`flow.l` implements `(co ...)` by carving a stack region per slot out of one
arena, moving the machine stack pointer into it, and `setjmp`/`longjmp`ing
between slots. On wasm the *arena* survives untouched — it lands on Emscripten's
shadow stack, which is ordinary addressable memory — so only the control
transfer had to move out, exactly as for the host ABI. `src/flow.l.patch` maps:

| upstream | becomes |
| --- | --- |
| `setjmp (Src: (rst))` + `longjmp (Dst: (rst))` | `crtSwap(Src, Dst)` |
| … + `runCo` on the freshly carved stack | `crtStart(Src, Dst, …)` |
| the main coroutine's context | `crtMain()`, borrowing the host layer's fiber |
| `longjmp (Ca: (rst))` after a cross-coroutine `unwind` | `crtThrow(Ca, Src, Dst)` |

`src/crt_fiber.c` implements those over `emscripten_fiber_*`, keeping each
slot's fiber state in the trailing `jmp_buf` area the slot already had — 64
bytes needed against 184 available, so no struct or size changes.

Three things the design needed that were not obvious:

- **`_Co` has to restore its own stack pointer before switching.** Upstream
  leaves it moved and relies on the `longjmp` to restore it. With a fiber,
  leaving it moved points the originator's stack straight into the region it
  just handed the coroutine.
- **A throw has to be carried across the switch.** `unwind` does the
  bookkeeping, but the catch frame to land on is on the *other* coroutine's
  stack, so the target fiber finishes the `longjmp` locally on arrival
  (`crtThrow`). This applies to `_Throw` *and* to `err` — errors and throws
  are separate paths, and missing the second one cost a debugging round.
- **`crtMain` borrows the host layer's fiber** rather than making its own from
  the current context, so that exactly one fiber handle ever describes the
  interpreter's stack. Two handles for one stack happens to work under strict
  nesting, but it is a latent trap not worth leaving in.

There was also a bug of mine worth recording, because the failure mode is
misleading: slots are `alloca`'d, so a slot the switcher has not seen holds
stale stack data rather than zeroes. Reusing an Asyncify stack pointer out of
it faults *inside* the context switch, and looked fine at first only because
fresh wasm memory is zeroed — it started failing once the arena had been
written. A magic word now distinguishes initialised slots from garbage.

### Prototype B is now a dead end

Coroutines need real stack switching whatever the host does, so "no Asyncify"
was never actually on the table once `(co ...)` is in scope. Prototype B stays
in the test matrix only to document that.

### Two limits that are not bugs

Both were probed and turn out to be properties of the host or the platform, and
both behave the same way on native:

- **Concurrent coroutine count is the host's to set.** The arena comes out of
  the caller's stack buffer, so 1 MB — what `sdl2gui.c` passes — holds about a
  dozen coroutines at the default 64 kB `$StkSize`, and overruns beyond that
  natively too. Native corrupts memory silently; wasm traps, which is at least
  louder. With an 8 MB buffer both run 56 coroutines.
- **`$StkLimit` overflow detection is calibrated differently.** It compares the
  stack pointer against a low-water mark, and on wasm only address-taken locals
  land on the shadow stack it measures, so frames are far smaller. Deep
  recursion inside a coroutine overflows at ~300 frames natively but not until
  ~1500 on wasm64. Both end in a clean Lisp `Stack overflow`, never a trap —
  only the depth differs. The suite therefore only asserts depths where the two
  agree.

## The browser demo

    make -f Makefile.wasm PIL=~/src/pil21 browser
    cd ../bin/web && python3 -m http.server 8791     # wasm cannot load from file://

`bin/web/index.html` puts `lib/gui.l` on a canvas. There are **no DOM
bindings**: PicoLisp draws into a pixel buffer, JS views that buffer directly
as `ImageData` — `SDL_PIXELFORMAT_ABGR8888` is byte-identical to canvas RGBA on
little-endian, so nothing is converted — and mouse and keyboard events are
forwarded to `(fbDn)`, `(fbMove)`, `(fbClick)`, `(fbUp)` and `(fbKey)`
following `sdl2gui.c`'s state machine. The page also has an expression box, so
it doubles as a REPL.

`src/browser/host_browser.c` is the whole C surface: `pilStart`, `pilEval`,
`pilFrame`, `pilStop`, plus getters.

### Nothing that can suspend may return a value

The one real constraint. Any call that reaches a fiber swap unwinds out to the
JS boundary and is rewound by Emscripten's fiber trampoline. The work completes
inside the original JS call — so from JS these look synchronous, which is
convenient — but the **return value does not survive the round trip**: JS sees
the dummy value from the unwinding return, not the real one.

So the suspending entry points are all `void`, and results come back afterwards
through getters that cannot suspend. `ccall({async: true})` does *not* fix it:
the fiber trampoline is not Asyncify's sleep/wake path, so `Asyncify.whenDone()`
resolves with the same stale value. This cost a debugging round, and it is the
first thing to know when writing another host.

Also: pointers are `BigInt` under `MEMORY64`, so they need `Number()` before
use as typed-array offsets.

### Drawing into the framebuffer from the expression box

`fb.l`'s primitives are ordinary builtins, so they work from the REPL and write
straight into the pixel buffer:

    (rect 300 100 200 100 20 (hex "FF0000FF"))     ; x y dx dy corner-radius col
    (dot 50 50 (hex "FF00FF00"))
    (clear 0 0 800 600)
    (fonts "FreeSansB")                            ; load the face first
    (pico~font 48 "FreeSansB")
    (pico~color (hex "FF00FFFF") 0)
    (render 200 300 "Hello")

`col` is **0xAABBGGRR** — alpha, blue, green, red — matching the ABGR8888
buffer, so `FF0000FF` is opaque red.

Two names have to be qualified: `lib/gui.l` defines its own `font` and `color`
(building `+Font` objects and component lists), and with `--symbols gui` those
shadow `fb.l`'s. `gui.l` reaches the builtins as `pico~font` / `pico~color`
itself, so the REPL does the same. Unqualified `font` at top level fails with
`(link This)` / `Not making`, which is correct behaviour, not a port problem —
native does the same. `(fonts ...)` and `(render ...)` are not shadowed.

The page redraws the GUI *without* repainting the background for expression-box
input, so direct drawing stays on screen; events and the demo buttons do repaint
(they have to, so closing a form removes its pixels). `(clear 0 0 800 600)`
wipes it.

### An uncaught Lisp error leaves the module unusable

The one real behavioural cliff, and worth knowing before embedding anything.

An uncaught error ends in `bye` (`main.l:127`), which does `(unwind null)` —
tearing down every catch frame and coroutine — and then calls `exit()`.
**`exit()` cannot terminate a wasm module.** Natively the process just exits;
here the interpreter is left half dismantled, and the next call into it dies
with "null function or function signature mismatch".

It also cannot be detected after the fact: when the interpreter calls `exit()`,
the fiber trampoline returns to JS rather than resuming the caller, so nothing
after `evaluate()` in the host ever runs. `host_browser.c` therefore checks
`$InBye` on *entry* to each call, which is visible by then, and turns itself
into a no-op so the page can report it instead of crashing.

The actual fix is not to let errors get that far. Everything the page evaluates
is wrapped in the catch-all tag:

    (catch '(NIL) <expr>)

`err` has a branch specifically for a NIL tag — `(if (nil? (car Tag)) (val $Msg) @)`
— so this catches any error and hands back the message as a string. Mind the
quoting: `'` reads as a dotted pair, so `'(NIL)` is **not** `(quote (NIL))`, and
the latter makes `err` call `subStr` on a list and spin forever. That is the
gotcha CLAUDE.md warns about, and it cost a debugging round here.

### No `--wrap` needed for the console

CLAUDE.md expected `-Wl,--wrap=_putStdout,--wrap=_getStdin`. It turns out
Emscripten's default stdio routing already delivers console output. It arrives
on `printErr` rather than `print`, because `_putStdout` (`io.l:1090`) falls back
to `putStderr` unless the current `$OutFile` is fd 1 — **which is exactly what
it does natively too**, so nothing is off. The page routes both to its log.

Debug mode (`"+"`) is deliberately off in the browser: it drops into a REPL on
stdin, and a browser has none. The init vector ends with `"-"` instead.

### Verifying it in a real browser

A headless screenshot cannot tell you whether a 1.9 MB Asyncify module ever
finished loading — Firefox's `--screenshot` fires around the load event and
exits first, which produced a convincingly blank canvas for a while. So:

    make -f Makefile.wasm PIL=~/src/pil21 browser-test

`selftest.html` reports each step back with `fetch()` and uploads the rendered
canvas; `testserver.py` collects both; `run-browser-test.sh` diffs every digest
against `bin/stubgui-upstream` and prints pass/fail. Phase 1 drives the exports;
**phase 2 loads `index.html` unmodified in an iframe and drives it through its
own listeners**, so the blit and the event wiring are covered, not just the
exports. Rendered frames land in `/tmp/minlib-browser/*.png`.

Phase 2 immediately earned its keep: `setPointerCapture` throws for a
`pointerId` that is not an active pointer, which killed the entire pointerdown
handler. It is guarded now.

No COOP/COEP headers are needed — single-threaded Asyncify. Serve `.wasm` as
`application/wasm` and enable gzip.

## Recommendation, and what to ask upstream

Prototype A plus fiber-per-coroutine-slot is the answer: it preserves the
documented C surface, so `sdl2gui.c` and any future JS host need no changes,
and it is the only route that supports the GUI. Asyncify costs **+13% module
size** (1893 KB against 1674 KB) and a runtime delta too small for this suite
to measure.

The Asyncify cost is modest for the host hand-over because **the yield point is
shallow** — at swap time the interpreter fiber's stack is just `lispEntry →
lispMain → hostYield`. pil21's port needed Asyncify to suspend from deep inside
`getStdin` in a blocking REPL, which is a much worse proposition. Coroutine
yields are *not* shallow, hence the per-slot Asyncify stacks sized at 8x the
coroutine's own stack.

Emscripten still instruments 513 of 584 functions, because the `invoke_*`
imports that emulated setjmp/longjmp generates are conservatively treated as
able to change Asyncify state. **`-sASYNCIFY_ONLY` is a trap here**: `lispMain`
and `picolisp` get inlined so the names do not exist, emcc only warns, and the
result silently stops after one expression while still exiting 0. It saved
217 KB for that risk. Don't.

Two questions for Alex Burger, worth asking separately:

1. **Would he take the `hostYield()` refactor upstream on its own?** It is
   small, platform-neutral, byte-identical natively, and it is what makes any
   of this possible. This is the one that matters. The same argument applies to
   the `flow.l` change: both just move a platform's stack assumptions out of
   the `.l` sources and behind a named C interface.
2. **Is fiber-per-coroutine-slot the shape he wants for `co`?** It works and
   costs 92 added / 31 removed lines across `flow.l` and `main.l`, much of the
   addition being comment, but it reaches further into the interpreter than a
   port should go uninvited, and he may prefer a different factoring of the
   same idea.

## Good news: the IR patching is much smaller than predicted

Of the three root causes CLAUDE.md expected to transfer from the pil21 port,
only two do, and one of those is trivial.

1. **`call_indirect` signature mismatch — still applies.** llvm.l's subr
   dispatch loads from `@$JumpTab` and calls as `i64(i64,i64)`, while 336 of the
   337 builtins are defined `i64(i64)`. Fixed as before with a dummy second
   `i64` parameter plus SSA renumbering, and additionally the 400 `@$JumpTab`
   bitcast operand types and 3 direct call sites — pil21's script had a latent
   bug here, defining a `direct_call_re` it never used.
2. **Function-pointer tagging — does *not* apply.** CLAUDE.md predicted the
   `+2` / `& ~3` tagging would need pil21's `@$FuncPtrTable` indirection. The
   current `llvm.l` has moved on: `SymTab` stores small *jump-table indices* and
   `@$JumpTab` holds the addresses. That already **is** the memory indirection
   `@$FuncPtrTable` was invented to synthesize, and it is layout-independent by
   construction. No SymTab rewriting, no dispatch patching. (Worth noting for
   the pil21 port too — that machinery is obsolete against today's backend.)
3. **16-byte heap alignment — applies, fixed, and now verified.** `@realloc` →
   `@__pil_realloc` over `emscripten_builtin_memalign(16, …)`. The GC-growth
   cases in the suite exercise it across multiple heap segments.
4. **`poll` — does not apply**, as predicted; `dec.l` has no such declaration.

`lib.so.c` and `lib.fb.c` compile under `emcc` unmodified, with no fork and no
stubs — so the pil21 port's biggest upstreaming liability is genuinely gone.

## Incidental finding: the init vector must be terminated

`README`'s ABI sketch does not mention it, but `loadAll` (`io.l:1487`) walks
`$AV` until it reaches a NULL slot or a bare `"-"`. `sdl2gui.c` gets a
terminator by accident: `init()` (`main.l:1111-1113`) *nulls* the trailing `"+"`
slot after reading it as the debug flag. A host that omits `"+"` and passes a
plain `static char *init[] = {"host", "lib.l"}` walks off the end of the array
and dies with a garbled `Open error`. A release host wants an explicit trailing
`"-"`. Worth a line in the README upstream.

## Files

Additive, except `main.l.patch` which is applied at build time:

| file | role |
| --- | --- |
| `src/Makefile.wasm` | all wasm and control builds; `src/Makefile` untouched |
| `src/run-tests.sh` | diffs every build against the native reference |
| `src/wasm_patch_ll.py` | IR post-processor |
| `src/wasm_support.c` | `__pil_realloc`, 16-byte aligned |
| `src/main.l.patch` | the `hostYield()` refactor |
| `src/main.crt.l.patch` | `crtThrow` for `err`, plus loading the patched `flow.l` |
| `src/flow.l.patch` | coroutine switching factored into C |
| `src/crt_fiber.c` | fiber per coroutine slot |
| `src/host.h` | the host interface |
| `src/host_setjmp.c` | hand-over by setjmp/longjmp (native control) |
| `src/host_fiber.c` | prototype A |
| `src/host_inverted.c` | prototype B |
| `src/stubhost.c` | stub host for the published ABI |
| `src/stubhost_inverted.c` | stub host for prototype B |
| `src/stubgui.c` | headless `lib/gui.l`, for comparing the framebuffer |
| `src/browser/host_browser.c` | the browser host: framebuffer plus four entry points |
| `src/browser/index.html` | the demo page |
| `src/browser/selftest.html` | browser-side regression test, incl. driving the page |
| `src/browser/testserver.py` | serves `bin/web` and collects what the page reports |
| `src/browser/run-browser-test.sh` | runs the browser test, pass/fail against native |
| `src/host.h` | also exposes `$InBye`, for the exit check above |
| `src/browser/test-node.js` | drives the browser build headlessly under Node |
| `src/test_exprs.h` | the shared test suite |

Still missing: `libsdl2-dev` is not installed, so `./mkGui` cannot build the
reference SDL2 host. `src/stubgui.c` covered milestone 4 without it.

Not attempted: a `(js ...)` primitive for real DOM access. The GUI needs none,
and CLAUDE.md is right that its shape is worth agreeing with upstream first.
