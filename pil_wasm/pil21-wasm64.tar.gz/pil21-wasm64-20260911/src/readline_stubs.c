// readline_stubs.c — minimum-viable stubs for GNU readline functions
// referenced by pil21's generated base.ll. Emscripten has no readline,
// and lib.emscripten.c already stubs the readline calls from C code;
// these are the ones that pil21 bootstrap emits as direct LLVM IR calls.
//
// These stubs are intentionally inert — no history, no completion.
// A script-driven invocation never reaches them in practice.

#include <stdlib.h>
#include <stddef.h>

// History API stubs
void add_history(const char *line) { (void)line; }
void clear_history(void) { }

// history_list returns an array of HIST_ENTRY pointers, NULL-terminated.
// Callers check for NULL, so returning NULL is a safe "no history" signal.
void **history_list(void) { return NULL; }

// Other history functions pil21 might emit calls for. Keeping them here
// preemptively saves a round-trip if they turn up in the next link attempt.
void *history_get(int n) { (void)n; return NULL; }
int history_length = 0;
int where_history(void) { return 0; }
int read_history(const char *filename) { (void)filename; return 0; }
int write_history(const char *filename) { (void)filename; return 0; }
void using_history(void) { }
void stifle_history(int n) { (void)n; }
