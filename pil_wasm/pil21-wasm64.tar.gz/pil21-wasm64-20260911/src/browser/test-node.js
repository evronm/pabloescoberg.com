// Headless test for the BROWSER build (bin/web/picolisp.js).
//
// The browser build's console I/O goes through Module.pilPutByte /
// Module.pilFlush / Module.pilReadByte instead of the Emscripten filesystem,
// so it can be driven from plain Node with no browser and no DOM. This mirrors
// exactly what src/browser/index.html does, which makes it a real test of the
// -DPIL_BROWSER wrappers and of the Asyncify blocking read.
//
// Usage:  echo '(+ 1 2)' | node src/browser/test-node.js
//         PIL_WAIT_MS=6000 node src/browser/test-node.js < script.l
//
// Note the wait is an env var, not argv: Emscripten forwards process.argv to
// main(), so an extra argument would be read as a PicoLisp file to load.
//
// Prints only what pil21 wrote to its console, so the output can be diffed
// against the native binary:
//
//     ./bin/picolisp < script.l > /tmp/out.native 2>&1
//     node src/browser/test-node.js < script.l > /tmp/out.browser
//     diff /tmp/out.native /tmp/out.browser

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const waitMs = Number(process.env.PIL_WAIT_MS) || 3000;
const script = fs.readFileSync(0);          // the .l script from stdin

const pilInput = [];                        // bytes awaiting __wrap__getStdin
let pilOutput = [];                         // bytes not yet decoded
const decoder = new TextDecoder('utf-8');
let collected = '';

// PIL_TRACE=1 logs I/O bridge activity to stderr. Use it when the REPL
// produces no output: it distinguishes "never started" from "started but
// produced nothing" from "produced output that was lost on the way out".
const trace = process.env.PIL_TRACE
  ? (s) => fs.writeSync(2, '[' + s + ']')
  : () => {};

globalThis.Module = {
  noInitialRun: false,
  noExitRuntime: true,

  pilPutByte(b) {
    pilOutput.push(b);
    if (b === 10) Module.pilFlush();
  },

  pilFlush() {
    trace('flush ' + pilOutput.length);
    if (!pilOutput.length) return;
    const bytes = new Uint8Array(pilOutput);
    pilOutput = [];
    collected += decoder.decode(bytes, {stream: true});
  },

  pilReadByte() {
    return pilInput.length ? pilInput.shift() : -1;
  },

  printErr(text) {
    if (!/prlimit/.test(text)) process.stderr.write(text + '\n');
  },

  onRuntimeInitialized() {
    trace('init script=' + script.length);
    for (const b of script) pilInput.push(b);
  }
};

// Load the glue the way a browser does: as a top-level script, NOT via
// require(). The generated JS starts with
//
//     var Module = typeof Module != 'undefined' ? Module : {};
//
// and under require() that `var` is hoisted into the module scope, shadowing
// globalThis.Module before the check runs — so our hooks would be silently
// discarded. In index.html both scripts are top-level and share one binding;
// runInThisContext reproduces that.
const webDir = path.resolve(__dirname, '../../bin/web');
globalThis.require = require;
globalThis.__dirname = webDir;
globalThis.__filename = path.join(webDir, 'picolisp.js');
vm.runInThisContext(fs.readFileSync(globalThis.__filename, 'utf8'), {
  filename: globalThis.__filename
});

// pil21's REPL is still blocked in getStdin when we stop; that is the correct
// steady state for an interactive REPL, so just report what it printed.
setTimeout(() => {
  trace('timer collected=' + collected.length);
  Module.pilFlush();
  // writeSync, not process.stdout.write: when stdout is a pipe or a file the
  // latter is asynchronous and process.exit() discards the pending write, so
  // the output silently vanishes exactly when it is being captured for a diff.
  fs.writeSync(1, collected);
  process.exit(0);
}, waitMs);
