#!/usr/bin/env python3
"""Post-process base.ll for wasm64 compatibility.

Transforms applied:
1. Renames @poll to @__pil_poll (bridges nfds_t i64/i32 mismatch).
2. Adds a dummy second i64 parameter to one-arg built-in functions so they
   match the (i64, i64) -> i64 call_indirect type used by PicoLisp's subr
   dispatch.  Renumbers SSA values accordingly.
3. Creates a memory-based function pointer indirection table.  PicoLisp's
   pointer-tagging scheme (address + 2, untag via & ~3) requires function
   "addresses" to be multiples of 4.  Wasm function table indices are
   sequential integers (1, 2, 3, ...) which breaks the scheme.  The fix:
   store function table indices in a global i64 array whose entries ARE
   8-byte-aligned, and point PicoLisp at array entries instead of raw
   table indices.  The subr dispatch is patched to load the real table
   index from the array before call_indirect.
"""

import re
import sys


# ── Regex patterns ──────────────────────────────────────────────────────────

# One-arg built-in function definition
one_arg_def_re = re.compile(r'^define i64 @(_\w+)\(i64\) align 8 \{')

# SymTab entry: address of a one-arg function (tagged with +2)
# Matches: bitcast (i64(i64)* @_FuncName to i8*), i32 2)
symtab_fn_re = re.compile(
    r'i64 ptrtoint \(i8\* getelementptr \(i8, i8\* bitcast \(i64\(i64\)\* @(_\w+) to i8\*\), i32 2\) to i64\)')
# Also match two-arg version (for __Meth etc.)
symtab_fn2_re = re.compile(
    r'i64 ptrtoint \(i8\* getelementptr \(i8, i8\* bitcast \(i64\(i64,i64\)\* @(_\w+) to i8\*\), i32 2\) to i64\)')

# The subr dispatch pattern: untag → inttoptr → call_indirect
# We need to insert a load between the untag and the inttoptr
dispatch_re = re.compile(
    r'^  (%\d+) = inttoptr i64 (%\d+) to i64\(i64,i64\)\*$')

# Direct calls to one-arg functions (before they become two-arg)
direct_call_re = re.compile(r'(call i64 @(_\w+)\(i64 )([^,)]+)\)')


# ── SSA renumbering ─────────────────────────────────────────────────────────

def bump_ssa(m):
    """Increment SSA value numbers >= 1 by 1."""
    prefix = m.group(1)
    n = int(m.group(2))
    if prefix == '$':
        return m.group(0)
    if n >= 1:
        return prefix + '%' + str(n + 1)
    return m.group(0)


def renumber_line(line):
    """Renumber %N -> %(N+1) for N >= 1, preserving %$N label refs."""
    return re.sub(r'((?:^|[^$]))%(\d+)', bump_ssa, line)


# ── Main ────────────────────────────────────────────────────────────────────

def main():
    # Optional --wasm-exceptions flag adds +exception-handling target feature
    wasm_exceptions = '--wasm-exceptions' in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if len(args) != 2:
        print(f"Usage: {sys.argv[0]} [--wasm-exceptions] input.ll output.ll", file=sys.stderr)
        sys.exit(1)

    with open(args[0]) as f:
        lines = f.readlines()

    # ── Pass 1: collect one-arg function names ──
    one_arg_fns = set()
    for line in lines:
        m = one_arg_def_re.match(line)
        if m:
            one_arg_fns.add(m.group(1))

    # ── Pass 2: collect all function names referenced in SymTab ──
    # These are functions whose address is taken and stored in the symbol
    # table.  They need entries in our indirection table.
    symtab_fns = []  # ordered list (preserve SymTab order)
    symtab_fn_set = set()
    for line in lines:
        for regex in (symtab_fn_re, symtab_fn2_re):
            for m in regex.finditer(line):
                fn = m.group(1)
                if fn not in symtab_fn_set:
                    symtab_fns.append(fn)
                    symtab_fn_set.add(fn)

    fn_to_idx = {fn: i for i, fn in enumerate(symtab_fns)}
    N = len(symtab_fns)

    # ── Pass 3: transform ──
    out = []
    in_one_arg_fn = False

    # We'll insert the indirection table right before the first 'define'.
    table_inserted = False

    for line in lines:
        # Rename functions whose signatures differ between native and wasm
        line = line.replace('@poll(', '@__pil_poll(')

        # Route pil21's allocator through a 16-byte aligned one.
        #
        # PicoLisp tags values in the low 4 bits of a pointer, so heap cells
        # must be 16-byte aligned. main.l's heapAlloc() takes its segments from
        # alloc(null, 8 * (HEAP + 1)) -> realloc, and Emscripten's wasm64
        # malloc is only 8-byte aligned (malloc(36) % 16 == 8). A segment on an
        # 8-mod-16 address makes every cell in it read back as a symbol.
        #
        # Renaming has a second, essential effect: it hides realloc's identity
        # from LLVM, which at -O2 would otherwise fold realloc(NULL, n) into
        # malloc(n) and bypass the replacement entirely. Wrapping malloc itself
        # with -Wl,--wrap is not an option -- it breaks Emscripten's own
        # malloc export ("undefined symbol: malloc, referenced by $Asyncify").
        line = line.replace('@realloc(', '@__pil_realloc(')

        # Note: _putStdout/_getStdin are NOT renamed. The browser build
        # intercepts them with -Wl,--wrap instead, which also catches the
        # Env.put/Env.get function pointers stored in @env.

        # Insert indirection table before the first function definition
        if not table_inserted and line.startswith('define '):
            # Build the indirection table: an array of function pointers
            # Each entry is the ptrtoint of a function, which in wasm will
            # be the function's table index.
            entries = []
            for fn in symtab_fns:
                if fn in one_arg_fns:
                    sig = 'i64(i64,i64)'
                elif fn == '__Meth':
                    sig = 'i64(i64,i64)'
                else:
                    # Check actual signature
                    sig = 'i64(i64,i64)'  # all go through subr dispatch
                entries.append(
                    f'  i64 ptrtoint ({sig}* @{fn} to i64)')
            out.append(f'@$FuncPtrTable = global [{N} x i64] [\n')
            out.append(',\n'.join(entries))
            out.append(f'\n]\n\n')
            table_inserted = True

        # Replace SymTab function address references with indirection table refs
        # From: ptrtoint (i8* getelementptr (i8, i8* bitcast (i64(i64)* @_Foo to i8*), i32 2) to i64)
        # To:   ptrtoint (i8* getelementptr (i8, i8* bitcast ([N x i64]* @$FuncPtrTable to i8*), i32 K*8+2) to i64)
        for regex in (symtab_fn_re, symtab_fn2_re):
            def replace_symtab(m):
                fn = m.group(1)
                if fn in fn_to_idx:
                    offset = fn_to_idx[fn] * 8 + 2  # 8 bytes per i64 entry, +2 for tag
                    return (f'i64 ptrtoint (i8* getelementptr (i8, i8* bitcast '
                            f'([{N} x i64]* @$FuncPtrTable to i8*), i32 {offset}) to i64)')
                return m.group(0)
            line = regex.sub(replace_symtab, line)

        # Transform one-arg function definitions
        attr = ' #0' if wasm_exceptions else ''
        m = one_arg_def_re.match(line)
        if m:
            line = line.replace('(i64) align 8 {', f'(i64, i64) align 8{attr} {{')
            in_one_arg_fn = True
            out.append(line)
            continue

        # Other function definitions
        if line.startswith('define ') and 'align 8 {' in line:
            if wasm_exceptions and '#0' not in line:
                line = line.replace('align 8 {', f'align 8{attr} {{')
            in_one_arg_fn = False

        # End of function
        if in_one_arg_fn and line.rstrip() == '}':
            in_one_arg_fn = False
            out.append(line)
            continue

        # Patch subr dispatch: add indirection load
        # Original:  %X = inttoptr i64 %Y to i64(i64,i64)*
        # Becomes:   %Xa = inttoptr i64 %Y to i64*
        #            %Xb = load i64, i64* %Xa
        #            %X  = inttoptr i64 %Xb to i64(i64,i64)*
        dm = dispatch_re.match(line)
        if dm:
            result_var = dm.group(1)
            src_var = dm.group(2)
            # Extract the number from result_var (e.g., %27 -> 27)
            result_num = int(result_var[1:])
            if in_one_arg_fn:
                result_num += 1  # account for renumbering
                src_var_num = int(src_var[1:])
                if src_var_num >= 1:
                    src_var = f'%{src_var_num + 1}'
            tmp_a = f'%_fpt{result_num}a'
            tmp_b = f'%_fpt{result_num}b'
            out.append(f'  {tmp_a} = inttoptr i64 {src_var} to i64*\n')
            out.append(f'  {tmp_b} = load i64, i64* {tmp_a}\n')
            actual_var = f'%{result_num}'
            out.append(f'  {actual_var} = inttoptr i64 {tmp_b} to i64(i64,i64)*\n')
            continue

        # Renumber SSA values inside one-arg functions
        if in_one_arg_fn:
            line = renumber_line(line)

        out.append(line)

    if wasm_exceptions:
        out.append('\nattributes #0 = { "target-features"="+exception-handling" }\n')

    with open(args[1], 'w') as f:
        f.writelines(out)


if __name__ == '__main__':
    main()
